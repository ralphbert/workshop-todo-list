export const environment = {
  production: true,
  api: '',
};
