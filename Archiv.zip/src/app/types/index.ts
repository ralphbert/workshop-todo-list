export interface TodoCreate {
  title: string;
  dueDate?: Date;
}
